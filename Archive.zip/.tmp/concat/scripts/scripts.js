'use strict';
angular.module('Filters', []).filter('durationFilter', [function () {
    return function (input) {
      return input.substring(input.lastIndexOf('T') + 1, input.lastIndexOf('M'));
    };
  }]);
'use strict';
angular.module('Services', []).factory('YoutubeService', [
  '$http',
  function ($http) {
    return {
      getVideoList: function () {
        var url = 'https://www.googleapis.com/youtube/v3/playlistItems?playlistId=UUtL3CrHPV6qHBaK1IUBoBIg&key=AIzaSyD-OH-663ZPQs9jWyi8rYWdXzK3P4Xtn9U&callback=JSON_CALLBACK&part=snippet&fields=items(snippet(description,thumbnails,title,resourceId))';
        var videoList = [];
        $http.jsonp(url).success(function (data) {
          console.log(data);
          angular.forEach(data.items, function (item) {
            videoList.push(item);
          });
        }).error(function (err) {
          throw new Error(err);
        });
        return videoList;
      },
      getVideoStatistics: function (id) {
        var statisticsURL = 'https://www.googleapis.com/youtube/v3/videos?id=' + id + '&key=AIzaSyD-OH-663ZPQs9jWyi8rYWdXzK3P4Xtn9U&callback=JSON_CALLBACK&part=statistics,contentDetails&fields=items(statistics, contentDetails(duration))';
        var statistics = [];
        $http.jsonp(statisticsURL).success(function (data) {
          console.log(data);
          angular.forEach(data.items, function (item) {
            statistics.push(item);
          });
        }).error(function (err) {
          throw new Error(err);
        });
        return statistics;
      }
    };
  }
]);
'use strict';
angular.module('Directives', []).directive('ngAdapt', [
  '$window',
  '$rootScope',
  function ($window, $rootScope) {
    return {
      scope: { num: '=px' },
      link: function (scope, element) {
        function getScrollbarWidth() {
          var outer = document.createElement('div');
          outer.style.visibility = 'hidden';
          outer.style.width = '100px';
          outer.style.msOverflowStyle = 'scrollbar';
          // needed for WinJS apps
          document.body.appendChild(outer);
          var widthNoScroll = outer.offsetWidth;
          // force scrollbars
          outer.style.overflow = 'scroll';
          // add innerdiv
          var inner = document.createElement('div');
          inner.style.width = '100%';
          outer.appendChild(inner);
          var widthWithScroll = inner.offsetWidth;
          // remove divs
          outer.parentNode.removeChild(outer);
          return widthNoScroll - widthWithScroll;
        }
        var win = angular.element($window);
        $rootScope.$watch('windowSize.width', function (newVal) {
          if (newVal > 767) {
            scope.num = 128;
            angular.element(element).css('width', newVal - scope.num - getScrollbarWidth());
          } else {
            scope.num = 0;
            angular.element(element).css('width', '100%');
          }
        });
        win.bind('resize', function () {
          $rootScope.$apply(function () {
            //15px to balance the difference in the beginning (due to scrollbar)
            $rootScope.windowSize.width = win.width() + getScrollbarWidth();
            $rootScope.windowSize.height = win.height();
          });
        });
      }
    };
  }
]).directive('twitterTimeline', [function () {
    return {
      restrict: 'A',
      scope: {
        cssUrl: '@',
        autoResize: '='
      },
      link: function (scope, element, attrs) {
        angular.element('body').removeAttr('data-twttr-rendered');
        element.attr('id', 'twitter-feed').attr('width', '100%' || attrs.width).attr('data-chrome', 'noheader transparent').attr('data-widget-id', attrs.twitterTimeline).addClass('twitter-timeline');
        function render() {
          var body = angular.element('.twitter-timeline').contents().find('body');
          if (scope.cssUrl) {
            body.prepend(angular.element('<link/>', {
              rel: 'stylesheet',
              href: scope.cssUrl,
              type: 'text/css'
            }));
          }
          function setHeight() {
            if (body.find('.stream').length === 0) {
              setTimeout(setHeight, 100);
            } else {
              body.find('.stream').addClass('stream-new').removeClass('stream').css('height', 'auto');
              angular.element('.twitter-timeline').css('height', body.height() + 20 + 'px');
            }
          }
          if (scope.autoResize) {
            setHeight();
          }
        }
        if (!angular.element('#twitter-wjs').length) {
          angular.element.getScript((/^http:/.test(document.location) ? 'http' : 'https') + '://platform.twitter.com/widgets.js', function () {
            render();
            angular.element('.twitter-timeline').load(render);
          });
        }
      }
    };
  }]).directive('ngShowNext', [
  '$document',
  function ($document) {
    return {
      restrict: 'A',
      scope: {
        start: '=start',
        step: '&step',
        limit: '&limit',
        first: '=first'
      },
      link: function (scope, element) {
        function toArray(obj) {
          var array = [];
          for (var i = 0; i < obj.length; i++) {
            array[i] = obj[i];
          }
          return array;
        }
        // 		TODO:
        // 		- ON LOAD SHOW FIRST SIX
        // 		- ON REACHING THE END, RESTART BUTTON
        // 		- DOING THE SAME BUT WITH PREV
        // 		**/
        element.bind('click', function () {
          var instafeed = $document[0].getElementById('instafeed');
          var children = instafeed.children;
          var childrenArray = toArray(children);
          var prevBlock = childrenArray.slice(scope.start, scope.start + scope.step());
          scope.start = scope.start + scope.step();
          var nextBlock = childrenArray.slice(scope.start, scope.start + scope.step());
          angular.forEach(nextBlock, function (item) {
            angular.element(item).removeClass('hidden');
          });
          angular.forEach(prevBlock, function (item) {
            angular.element(item).addClass('hidden');
          });
          scope.$apply(function () {
            console.log(instafeed);
          });
        });
      }
    };
  }
]).directive('ngAboutAnimate', [
  '$document',
  '$interval',
  function ($document, $interval) {
    return {
      restrict: 'A',
      scope: {
        steps: '&steps',
        section: '&section'
      },
      link: function (scope, element) {
        var steps = scope.steps();
        var _i = 0;
        var interval;
        var v = 2500;
        function addElements() {
          if (_i < steps.length) {
            console.log(steps[_i]);
            if (steps[_i].clear === false) {
              angular.element(element).append(steps[_i].content);
            } else {
              angular.element(element).empty();
              angular.element(element).append(steps[_i].content);
            }
            $interval.cancel(interval);
            v = steps[_i].interval;
            interval = $interval(addElements, v);
            _i++;
          }
        }
        interval = $interval(addElements, v);
      }
    };
  }
]);
'use strict';
angular.module('HomeModule', []).controller('HomeCtrl', [
  '$scope',
  function ($scope) {
    $scope.num = 128;
    $scope.section = 'home';
  }
]);
'use strict';
angular.module('VideosModule', []).controller('VideosCtrl', [
  '$scope',
  '$sce',
  '$animate',
  'YoutubeService',
  function ($scope, $sce, $animate, YoutubeService) {
    var baseVideoURL = 'http://www.youtube.com/embed/';
    var baseVideoId = '_Ah2nTHgMCI';
    $scope.section = 'videos';
    $scope.videoTitle = '"Putas Asesinas" de Roberto Bola\xf1o';
    $scope.videoURL = $sce.trustAsResourceUrl(baseVideoURL + baseVideoId);
    $scope.videoDesc = 'V\xeddeo promocional de l\'adaptaci\xf3 teatral del conte "Putas Asesinas" de Roberto Bola\xf1o.';
    $scope.videoList = YoutubeService.getVideoList();
    $scope.videoStatistics = YoutubeService.getVideoStatistics(baseVideoId);
    $scope.nowplaying = 'http://twitter.com/home?status=\xa1Hey!%20Echa%20un%20vistazo%20a%20' + $scope.videoTitle + '%20de%20OMartinGual+' + $scope.videoURL + '%20#nowplaying';
    $scope.videoChange = function (title, id, desc) {
      $scope.videoTitle = title;
      $scope.videoURL = $sce.trustAsResourceUrl(baseVideoURL + id);
      $scope.videoDesc = desc;
      $scope.videoStatistics = YoutubeService.getVideoStatistics(id);
    };
  }
]);
'use strict';
angular.module('FotosModule', []).controller('FotosCtrl', [
  '$scope',
  function ($scope) {
    $scope.section = 'fotos';
    $scope.start = 1;
    $scope.step = 6;
    $scope.limit = 18;
    $scope.first = true;
  }
]);
'use strict';
angular.module('SocialModule', []).controller('SocialCtrl', [
  '$scope',
  function ($scope) {
    $scope.section = 'social';
    $scope.title = '\xa1Charla comigo!';
    $scope.subtitle = 'Encu\xe9ntrame en las redes sociales';
    $scope.redesSociales = [
      {
        name: 'Twitter',
        logo: '',
        url: 'https://twitter.com/omartingual'
      },
      {
        name: 'LinkedIn',
        logo: '',
        url: 'http://www.linkedin.com/in/oriolmartingual'
      },
      {
        name: 'Facebook',
        logo: '',
        url: 'https://www.facebook.com/OMartinGual?fref=ts'
      }
    ];
  }
]);
'use strict';
angular.module('AboutMeModule', []).controller('AboutMeCtrl', [
  '$scope',
  function ($scope) {
    $scope.section = 'OMartinGual';
    $scope.stepsHeader = [
      {
        content: '',
        clear: false,
        interval: 6000
      },
      {
        content: '<h1>No soy \xe9ste</h1>',
        clear: true,
        interval: 2500
      },
      {
        content: '<h1>Tampoco \xe9ste</h1>',
        clear: true,
        interval: 2500
      },
      {
        content: '<h1>Sino \xe9ste</h1>',
        clear: true,
        interval: 2500
      },
      {
        content: '<h1>He trabajado para empresas como...</h1>',
        clear: true,
        interval: 6000
      },
      {
        content: '<h1>Y he realizado proyectos como<br>estos de aqu\xed</h1>',
        clear: true,
        interval: 5000
      },
      {
        content: '<h1>Ahora ya me conoces un poco m\xe1s</h1>',
        clear: true,
        interval: 5000
      },
      {
        content: '<h1>Aunque si necesitas m\xe1s,<br>contacta conmigo ;)</h1>',
        clear: true,
        interval: 5000
      }
    ];
    $scope.stepsBrackets = [
      {
        content: '<h1 class="typewriter threeD">Productor audiovisual.</h1>',
        clear: false,
        interval: 3000
      },
      {
        content: '<figure class="circle logo"><img src="/images/icons/nav/logo.png"></figure>',
        clear: false,
        interval: 3000
      },
      {
        content: '<figure class="circle nosoy"></figure>',
        clear: true,
        interval: 2500
      },
      {
        content: '<figure class="circle tampoco"></figure>',
        clear: true,
        interval: 2500
      },
      {
        content: '<figure class="circle nieste"></figure>',
        clear: true,
        interval: 2500
      },
      {
        content: '<figure class="company" id="tv3"><span></span><figcaption>TV3</figcaption></figure>',
        clear: true,
        interval: 2000
      },
      {
        content: '<figure class="company" id="impact"><span></span><figcaption>impactdigital.es</figcaption></figure>',
        clear: false,
        interval: 2000
      },
      {
        content: '<figure class="company" id="treceav"><span></span><figcaption>13av</figcaption></figure>',
        clear: false,
        interval: 2000
      },
      {
        content: '<p>5</p>',
        clear: true,
        interval: 5000
      },
      {
        content: '<p>6</p>',
        clear: true,
        interval: 5000
      },
      {
        content: '<p>7</p>',
        clear: true,
        interval: 5000
      }
    ];
  }
]);
'use strict';
angular.module('codeApp', [
  'ngResource',
  'ngRoute',
  'ngAnimate',
  'angular-blocks',
  'Filters',
  'Directives',
  'Services',
  'HomeModule',
  'VideosModule',
  'FotosModule',
  'SocialModule',
  'AboutMeModule'
]).config([
  '$routeProvider',
  '$locationProvider',
  function ($routeProvider, $locationProvider) {
    $routeProvider.when('/', {
      templateUrl: '/views/partials/home.html',
      controller: 'HomeCtrl'
    }).when('/videos', {
      templateUrl: '/views/partials/videos.html',
      controller: 'VideosCtrl'
    }).when('/fotos', {
      templateUrl: '/views/partials/fotos.html',
      controller: 'FotosCtrl'
    }).when('/social', {
      templateUrl: '/views/partials/social.html',
      controller: 'SocialCtrl'
    }).when('/sobre-mi', {
      templateUrl: '/views/partials/about_me.html',
      controller: 'AboutMeCtrl'
    }).otherwise({ redirectTo: '/' });
    $locationProvider.html5Mode(true);
  }
]).run([
  '$rootScope',
  '$window',
  function ($rootScope, $window) {
    $rootScope.menuItems = [
      {
        name: 'Home',
        href: '/home',
        img: '/images/icons/nav/logo.png',
        id: 'menu-icon-logo'
      },
      {
        name: 'Videos',
        href: '/videos',
        img: '/images/icons/nav/videos.png',
        id: 'menu-icon-videos'
      },
      {
        name: 'LIKES',
        href: '',
        img: 'images/icons/nav/likes.png',
        click: true,
        id: 'menu-icon-likes'
      },
      {
        name: 'Fotos',
        href: '/fotos',
        img: '/images/icons/nav/fotos.png',
        id: 'menu-icon-fotos'
      },
      {
        name: 'Sobre m\xed',
        href: '/sobre-mi',
        img: '/images/icons/nav/sobre-mi.png',
        id: 'menu-icon-sobre'
      },
      {
        name: 'Social',
        href: '/social',
        img: '/images/icons/nav/social.png',
        id: 'menu-icon-social'
      },
      {
        name: 'Comparte',
        href: '',
        img: '/images/icons/nav/comparte.png',
        click: true,
        id: 'menu-icon-comparte'
      }
    ];
    $rootScope.windowSize = {
      width: angular.element($window).width(),
      height: angular.element($window).height()
    };
    $rootScope.socialIcons = [
      {
        klass: 'icon-fb',
        url: 'http://www.facebook.com/share.php?u=' + document.URL + '&title=OMartinGual%20Portfolio'
      },
      {
        klass: 'icon-tw',
        url: 'http://twitter.com/home?status=\xa1Hey!%20Echa%20un%20vistazo%20a%20los%20videos%20de%20OMartinGual+' + document.URL
      },
      {
        klass: 'icon-gplus',
        url: 'https://plus.google.com/share?url=' + document.URL
      }
    ];
    $rootScope.likes = false;
    $rootScope.comparte = false;
  }
]);