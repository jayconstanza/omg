'use strict';
angular.module('codeApp', [
  'ngResource',
  'ngRoute',
  'ngAnimate',
  'angular-blocks',
  'Directives',
  'Filters',
  'Services',
  'HomeModule',
  'VideosModule'
]).config([
  '$routeProvider',
  '$locationProvider',
  function ($routeProvider, $locationProvider) {
    $routeProvider.when('/', {
      templateUrl: 'views/partials/home.html',
      controller: 'HomeCtrl'
    }).when('/videos', {
      templateUrl: 'views/partials/videos.html',
      controller: 'VideosCtrl'
    }).otherwise({ redirectTo: '/' });
    $locationProvider.html5Mode(true);
  }
]);
'use strict';
angular.module('Directives', []).directive('ngAdapt', [
  '$window',
  '$rootScope',
  function ($window, $rootScope) {
    return {
      scope: { num: '&px' },
      link: function (scope, element) {
        var win = angular.element($window);
        $rootScope.$watch('windowSize.width', function (newVal) {
          angular.element(element).css('width', newVal - scope.num() - 15);
        });
        win.bind('resize', function () {
          $rootScope.$apply(function () {
            //15px to balance the difference in the beginning (due to scrollbar)
            $rootScope.windowSize.width = win.width() + 15;
            $rootScope.windowSize.height = win.height();
          });
        });
      }
    };
  }
]);
'use strict';
angular.module('Filters', []).filter('durationFilter', [function () {
    return function (input) {
      return input.substring(input.lastIndexOf('T') + 1, input.lastIndexOf('M'));
    };
  }]);
'use strict';
angular.module('Services', []).factory('YoutubeService', [
  '$http',
  function ($http) {
    return {
      getVideoList: function () {
        var url = 'https://www.googleapis.com/youtube/v3/playlistItems?playlistId=UUtL3CrHPV6qHBaK1IUBoBIg&key=AIzaSyD-OH-663ZPQs9jWyi8rYWdXzK3P4Xtn9U&callback=JSON_CALLBACK&part=snippet&fields=items(snippet(description,thumbnails,title,resourceId))';
        var videoList = [];
        $http.jsonp(url).success(function (data) {
          console.log(data);
          angular.forEach(data.items, function (item) {
            videoList.push(item);
          });
        }).error(function (err) {
          throw new Error(err);
        });
        return videoList;
      },
      getVideoStatistics: function (id) {
        var statisticsURL = 'https://www.googleapis.com/youtube/v3/videos?id=' + id + '&key=AIzaSyD-OH-663ZPQs9jWyi8rYWdXzK3P4Xtn9U&callback=JSON_CALLBACK&part=statistics,contentDetails&fields=items(statistics, contentDetails(duration))';
        var statistics = [];
        $http.jsonp(statisticsURL).success(function (data) {
          console.log(data);
          angular.forEach(data.items, function (item) {
            statistics.push(item);
          });
        }).error(function (err) {
          throw new Error(err);
        });
        return statistics;
      }
    };
  }
]);
'use strict';
angular.module('HomeModule', []).controller('HomeCtrl', [
  '$scope',
  '$rootScope',
  '$window',
  function ($scope, $rootScope, $window) {
    $rootScope.menuItems = [
      {
        name: 'Home',
        href: '/home',
        img: '/images/icons/nav/logo.png',
        id: 'menu-icon-logo'
      },
      {
        name: 'Videos',
        href: '/videos',
        img: '/images/icons/nav/videos.png',
        id: 'menu-icon-videos'
      },
      {
        name: 'LIKES',
        href: '',
        img: 'images/icons/nav/likes.png',
        click: true,
        id: 'menu-icon-likes'
      },
      {
        name: 'Fotos',
        href: '/fotos',
        img: '/images/icons/nav/fotos.png',
        id: 'menu-icon-fotos'
      },
      {
        name: 'Sobre m\xed',
        href: '/sobre-mi',
        img: '/images/icons/nav/sobre-mi.png',
        id: 'menu-icon-sobre'
      },
      {
        name: 'Social',
        href: '/social',
        img: '/images/icons/nav/social.png',
        id: 'menu-icon-social'
      }
    ];
    $rootScope.windowSize = {
      width: angular.element($window).width(),
      height: angular.element($window).height()
    };
    $rootScope.socialIcons = [
      {
        klass: 'icon-fb',
        url: 'http://www.facebook.com/share.php?u=' + document.URL + '&title=OMartinGual%20Portfolio'
      },
      {
        klass: 'icon-tw',
        url: 'http://twitter.com/home?status=\xa1Hey!%20Echa%20un%20vistazo%20a%20los%20videos%20de%20OMartinGual+' + document.URL
      },
      {
        klass: 'icon-gplus',
        url: 'https://plus.google.com/share?url=' + document.URL
      }
    ];
    $rootScope.likes = false;
    $scope.section = 'home';
  }
]);
'use strict';
angular.module('VideosModule', []).controller('VideosCtrl', [
  '$scope',
  '$sce',
  'YoutubeService',
  function ($scope, $sce, YoutubeService) {
    var baseVideoURL = 'http://www.youtube.com/embed/';
    var baseVideoId = '_Ah2nTHgMCI';
    $scope.section = 'videos';
    $scope.videoTitle = '"Putas Asesinas" de Roberto Bola\xf1o';
    $scope.videoURL = $sce.trustAsResourceUrl(baseVideoURL + baseVideoId);
    $scope.videoDesc = 'V\xeddeo promocional de l\'adaptaci\xf3 teatral del conte "Putas Asesinas" de Roberto Bola\xf1o.';
    $scope.videoList = YoutubeService.getVideoList();
    $scope.videoStatistics = YoutubeService.getVideoStatistics(baseVideoId);
    $scope.videoChange = function (title, id, desc) {
      $scope.videoTitle = title;
      $scope.videoURL = $sce.trustAsResourceUrl(baseVideoURL + id);
      $scope.videoDesc = desc;
      $scope.videoStatistics = YoutubeService.getVideoStatistics(id);
    };
  }
]);